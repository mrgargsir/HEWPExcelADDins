document.getElementById('reloadBtn').addEventListener('click', () => {
  chrome.runtime.reload();
});
